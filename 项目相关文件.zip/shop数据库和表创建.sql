create database shop;
use shop;
DROP TABLE IF EXISTS product;
create table product(
    proid int(4) not null auto_increment,
    sku int(4) not null,
    title varchar(64) not null,
    primary key(proid)
);

DROP TABLE IF EXISTS offerPrice;
create table offerPrice(
    ofpid int(4) not null auto_increment,
    price double(6,2) not null,
    proid int(4)   not null,
    typeid int(4) not null,
    EffetiveStartDate date default null,
    EffetiveEndDate date default null,
    primary key(ofpid),
    foreign key(proid) references product(proid)
);

insert into product(proid, sku, title) values(1,7001,'衣服1');
insert into product(proid, sku, title) values(2,7002,'衣服2');
insert into product(proid, sku, title) values(3,7003,'衣服3');
insert into product(proid, sku, title) values(4,8001,'电子1');

insert into offerPrice(ofpid, price, proid, typeid, EffetiveStartDate, EffetiveEndDate) values(1,123,1,1,'2019-07-03','2020-09-08');
insert into offerPrice(ofpid, price, proid, typeid, EffetiveStartDate, EffetiveEndDate) values(2,456,2,1,'2019-07-03','2020-09-08');
insert into offerPrice(ofpid, price, proid, typeid, EffetiveStartDate, EffetiveEndDate) values(3,132,3,1,'2019-07-03','2020-09-08');
insert into offerPrice(ofpid, price, proid, typeid, EffetiveStartDate, EffetiveEndDate) values(4,6000,4,2,'2019-07-03','2020-09-08');
